-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 23, 2021 at 07:36 AM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vsconstructions`
--

-- --------------------------------------------------------

--
-- Table structure for table `acl_files`
--

DROP TABLE IF EXISTS `acl_files`;
CREATE TABLE IF NOT EXISTS `acl_files` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `acl_rules` int(11) DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `acl_files`
--

INSERT INTO `acl_files` (`id`, `acl_rules`, `file`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, 'loading_image.jpg', '2021-11-10 13:19:00', '2021-11-10 13:19:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `acl_rules`
--

DROP TABLE IF EXISTS `acl_rules`;
CREATE TABLE IF NOT EXISTS `acl_rules` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `disk` varchar(191) NOT NULL,
  `path` varchar(191) NOT NULL,
  `access` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `acl_rules_user_id_foreign` (`user_id`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `chat_groups`
--

DROP TABLE IF EXISTS `chat_groups`;
CREATE TABLE IF NOT EXISTS `chat_groups` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_name` varchar(191) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `chat_groups`
--

INSERT INTO `chat_groups` (`id`, `group_name`, `user_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'team discussion', 2, '2021-11-11 05:51:19', '2021-11-11 05:51:19', NULL),
(2, 'meet', 4, '2021-11-12 06:15:28', '2021-11-12 06:15:28', NULL),
(3, 'Alpha', 2, '2021-11-18 13:45:02', '2021-11-18 13:45:02', NULL),
(4, 'Beta', 2, '2021-11-18 13:45:15', '2021-11-18 13:45:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat_group_members`
--

DROP TABLE IF EXISTS `chat_group_members`;
CREATE TABLE IF NOT EXISTS `chat_group_members` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` varchar(191) NOT NULL,
  `group_member_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `chat_group_members`
--

INSERT INTO `chat_group_members` (`id`, `group_id`, `group_member_id`, `user_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '1', 2, 2, '2021-11-11 05:51:19', '2021-11-11 05:51:19', NULL),
(2, '1', 3, 2, '2021-11-11 09:20:26', '2021-11-11 09:32:36', '2021-11-11 09:32:36'),
(3, '1', 4, 2, '2021-11-11 09:32:27', '2021-11-11 09:33:29', '2021-11-11 09:33:29'),
(4, '1', 3, 2, '2021-11-11 09:33:07', '2021-11-11 09:33:31', '2021-11-11 09:33:31'),
(5, '1', 3, 2, '2021-11-11 09:33:48', '2021-11-11 09:48:41', '2021-11-11 09:48:41'),
(6, '1', 4, 2, '2021-11-11 09:39:45', '2021-11-11 09:45:02', '2021-11-11 09:45:02'),
(7, '1', 4, 2, '2021-11-11 09:48:33', '2021-11-11 09:49:00', '2021-11-11 09:49:00'),
(8, '1', 3, 2, '2021-11-11 09:48:53', '2021-11-15 13:45:37', '2021-11-15 13:45:37'),
(9, '2', 4, 4, '2021-11-12 06:15:28', '2021-11-12 06:15:28', NULL),
(10, '2', 2, 4, '2021-11-12 06:15:37', '2021-11-12 06:15:37', NULL),
(11, '2', 3, 4, '2021-11-12 06:15:46', '2021-11-12 06:15:46', NULL),
(12, '1', 3, 2, '2021-11-15 13:45:38', '2021-11-15 13:46:56', '2021-11-15 13:46:56'),
(13, '1', 3, 2, '2021-11-18 09:30:53', '2021-11-18 09:30:58', '2021-11-18 09:30:58'),
(14, '1', 3, 2, '2021-11-18 09:31:14', '2021-11-18 09:31:16', '2021-11-18 09:31:16'),
(15, '1', 3, 2, '2021-11-18 09:32:50', '2021-11-18 09:32:50', '2021-11-18 09:32:50'),
(16, '1', 3, 2, '2021-11-18 09:34:15', '2021-11-18 09:34:15', '2021-11-18 09:34:15'),
(17, '1', 3, 2, '2021-11-18 09:35:02', '2021-11-18 09:35:02', '2021-11-18 09:35:02'),
(18, '1', 3, 2, '2021-11-18 09:36:45', '2021-11-18 09:36:45', '2021-11-18 09:36:45'),
(19, '1', 3, 2, '2021-11-18 09:39:23', '2021-11-18 09:39:23', '2021-11-18 09:39:23'),
(20, '1', 4, 2, '2021-11-18 09:39:33', '2021-11-18 09:39:33', '2021-11-18 09:39:33'),
(21, '1', 3, 2, '2021-11-18 10:57:28', '2021-11-18 10:57:28', '2021-11-18 10:57:28'),
(22, '3', 2, 2, '2021-11-18 13:45:02', '2021-11-18 13:45:02', NULL),
(23, '4', 2, 2, '2021-11-18 13:45:15', '2021-11-18 13:45:15', NULL),
(24, '3', 3, 2, '2021-11-18 13:50:33', '2021-11-18 14:08:51', '2021-11-18 14:08:51'),
(25, '3', 3, 2, '2021-11-18 14:08:51', '2021-11-18 14:08:51', '2021-11-18 14:08:51'),
(26, '3', 4, 2, '2021-11-18 14:08:51', '2021-11-18 14:17:54', '2021-11-18 14:17:54'),
(27, '3', 3, 2, '2021-11-18 14:17:52', '2021-11-18 14:22:03', '2021-11-18 14:22:03'),
(28, '3', 4, 2, '2021-11-18 14:17:54', '2021-11-18 14:23:49', '2021-11-18 14:23:49'),
(29, '3', 3, 2, '2021-11-18 14:22:08', '2021-11-18 14:22:14', '2021-11-18 14:22:14'),
(30, '3', 3, 2, '2021-11-18 14:23:59', '2021-11-18 14:25:36', '2021-11-18 14:25:36'),
(31, '3', 3, 2, '2021-11-18 14:25:39', '2021-11-18 14:40:33', '2021-11-18 14:40:33'),
(32, '3', 4, 2, '2021-11-18 14:49:41', '2021-11-18 14:49:44', '2021-11-18 14:49:44'),
(33, '3', 3, 2, '2021-11-18 14:49:51', '2021-11-18 14:49:51', NULL),
(34, '1', 3, 2, '2021-11-23 06:37:03', '2021-11-23 06:37:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company_roles`
--

DROP TABLE IF EXISTS `company_roles`;
CREATE TABLE IF NOT EXISTS `company_roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_roles_company_id_foreign` (`company_id`)
) ;

--
-- Dumping data for table `company_roles`
--

INSERT INTO `company_roles` (`id`, `name`, `description`, `company_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Technical', NULL, 1, '2021-11-10 12:09:59', '2021-11-10 12:09:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `description` longtext,
  `created_by` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `description`, `created_by`, `company_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Support Department', NULL, 2, 1, NULL, '2021-11-10 12:11:08', '2021-11-10 12:11:08');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
CREATE TABLE IF NOT EXISTS `documents` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `users` json DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `attachment` json DEFAULT NULL,
  `title` longtext,
  `folder` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `documents_folders`
--

DROP TABLE IF EXISTS `documents_folders`;
CREATE TABLE IF NOT EXISTS `documents_folders` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `folder` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `documents_threads`
--

DROP TABLE IF EXISTS `documents_threads`;
CREATE TABLE IF NOT EXISTS `documents_threads` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `document_id` int(11) DEFAULT NULL,
  `title` longtext,
  `folder` int(11) DEFAULT NULL,
  `attachment` json DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `users` json DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` longtext,
  `users` json DEFAULT NULL,
  `referenceto` varchar(191) DEFAULT NULL,
  `references` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `memos`
--

DROP TABLE IF EXISTS `memos`;
CREATE TABLE IF NOT EXISTS `memos` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_by` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `project_number` varchar(191) DEFAULT NULL,
  `correspondence_no` varchar(191) DEFAULT NULL,
  `datetime` varchar(191) DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `response` int(11) DEFAULT NULL,
  `attachment` json DEFAULT NULL,
  `tag` json DEFAULT NULL,
  `location` varchar(191) DEFAULT NULL,
  `memo` longtext,
  `image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `memos`
--

INSERT INTO `memos` (`id`, `created_by`, `company_id`, `project_id`, `project_number`, `correspondence_no`, `datetime`, `subject`, `response`, `attachment`, `tag`, `location`, `memo`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 1, 1, '1', '11', '2021-11-12T18:06', 'Basic', NULL, '[\"1636720701618e603d423c70.png\"]', NULL, 'Mohali', '<p>Des</p>', '16372119233870.png', '2021-11-12 12:38:21', '2021-11-18 05:05:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `memo_threads`
--

DROP TABLE IF EXISTS `memo_threads`;
CREATE TABLE IF NOT EXISTS `memo_threads` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `memo_id` int(11) DEFAULT NULL,
  `memo` longtext,
  `user_id` int(11) DEFAULT NULL,
  `attachment` json DEFAULT NULL,
  `tag` json DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `memo_threads`
--

INSERT INTO `memo_threads` (`id`, `memo_id`, `memo`, `user_id`, `attachment`, `tag`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Having issue', 2, '[\"1636720701618e603d423c70.png\"]', NULL, NULL, '2021-11-12 12:40:00', '2021-11-12 12:40:00', NULL),
(2, 1, 'main issue', 2, '[\"1636724624618e6f900c99d0.jpg\"]', NULL, NULL, '2021-11-12 13:43:44', '2021-11-12 13:43:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `memo_users`
--

DROP TABLE IF EXISTS `memo_users`;
CREATE TABLE IF NOT EXISTS `memo_users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `memo_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `memo_users`
--

INSERT INTO `memo_users` (`id`, `user_id`, `memo_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 1, '2021-11-12 12:38:21', '2021-11-12 12:38:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `message` longtext NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:message, 2:file',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `parent_id`, `message`, `type`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, 'Hello', 1, 1, '2021-11-10 12:27:35', '2021-11-10 12:27:35', NULL),
(2, NULL, 'Hello', 1, 1, '2021-11-10 12:27:48', '2021-11-10 12:27:48', NULL),
(3, NULL, 'hello', 1, 1, '2021-11-11 07:13:41', '2021-11-11 07:13:41', NULL),
(4, NULL, 'how are you?', 1, 1, '2021-11-11 07:14:16', '2021-11-11 07:14:16', NULL),
(5, NULL, 'Hello', 1, 1, '2021-11-11 12:31:50', '2021-11-11 12:31:50', NULL),
(6, NULL, 'Hello Niya', 1, 1, '2021-11-11 12:32:12', '2021-11-11 12:32:12', NULL),
(7, NULL, 'Hello Pathor', 1, 1, '2021-11-11 12:32:34', '2021-11-11 12:32:34', NULL),
(8, NULL, 'I am good neha.what about you?', 1, 1, '2021-11-11 12:33:29', '2021-11-11 12:33:29', NULL),
(9, NULL, 'Hello Aro..', 1, 1, '2021-11-11 12:33:48', '2021-11-11 12:33:48', NULL),
(10, NULL, '1636634218618d0e6ab807f.gif', 2, 1, '2021-11-11 12:36:58', '2021-11-11 12:36:58', NULL),
(11, NULL, '1636634243618d0e831a989.png', 2, 1, '2021-11-11 12:37:23', '2021-11-11 12:37:23', NULL),
(12, NULL, '1636709441618e34416a961.jpg', 2, 1, '2021-11-12 09:30:41', '2021-11-12 09:30:41', NULL),
(13, NULL, 'Hello', 1, 1, '2021-11-12 09:30:42', '2021-11-12 09:30:42', NULL),
(14, NULL, '1636709535618e349fc17b6.png', 2, 1, '2021-11-12 09:32:15', '2021-11-12 09:32:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_02_06_174631_make_acl_rules_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2020_08_11_032752_create_messages_table', 1),
(6, '2020_08_11_032816_create_user_messages_table', 1),
(7, '2020_08_11_111234_create_jobs_table', 1),
(8, '2021_04_30_100857_create_user_company_table', 1),
(9, '2021_04_30_110013_add_status_user_company_table', 1),
(10, '2021_04_30_114307_add_columns_to_users_table', 1),
(11, '2021_04_30_130424_create_user_roles_table', 1),
(12, '2021_05_01_052627_removestatus', 1),
(13, '2021_05_01_052845_add_status_users_table', 1),
(14, '2021_05_03_064937_create_company_roles_table', 1),
(15, '2021_05_03_065039_add_field_to_users_table', 1),
(16, '2021_05_05_163532_defaultvalue_to_users_table', 1),
(17, '2021_05_11_093044_create_events_table', 1),
(18, '2021_05_12_053140_create_chat_group_table', 1),
(19, '2021_05_12_053222_create_chat_group_members_table', 1),
(20, '2021_05_12_144116_add_column_user_messages_table', 1),
(21, '2021_05_17_100842_create_projects_table', 1),
(22, '2021_05_17_125432_create_project_types_table', 1),
(23, '2021_05_17_140449_add_status_project_types_table', 1),
(24, '2021_05_18_060720_alter_receiver_id_nullable_user_messages', 1),
(25, '2021_05_20_074210_create_project_users_table', 1),
(26, '2021_06_01_102032_create_memos_table', 1),
(27, '2021_06_01_132614_create_memo_users_table', 1),
(28, '2021_06_03_105428_create_memo_threads_table', 1),
(29, '2021_06_14_134032_add_columns_to_events_table', 1),
(30, '2021_06_15_064113_add_created_by_to_events_table', 1),
(31, '2021_06_15_102138_change_description_type_to_events_table', 1),
(32, '2021_06_17_060226_create_project_attachments_table', 1),
(33, '2021_06_17_131403_chang_referencefield_to_events_table', 1),
(34, '2021_06_22_144452_create_documents_table', 1),
(35, '2021_06_23_072159_create_documents_attachments_table', 1),
(36, '2021_06_25_102545_add_deleted_at_to_events_table', 1),
(37, '2021_06_25_102752_add_deleted_at_to_messages_table', 1),
(38, '2021_06_25_102846_add_deleted_at_to_user_messages_table', 1),
(39, '2021_06_25_102902_add_deleted_at_to_user_roles_table', 1),
(40, '2021_06_28_105125_change_table_name_to_documents_attachments_table', 1),
(41, '2021_06_28_105447_add_fields_to_documents_table', 1),
(42, '2021_07_09_115039_create_documents_folders_table', 1),
(43, '2021_07_12_131541_add_folderid_to_documents_table', 1),
(44, '2021_07_12_131631_add_folderid_to_documents_threads_table', 1),
(45, '2021_07_21_060743_change_title_type_to_documents_table', 1),
(46, '2021_07_21_060824_change_title_type_to_documents_threads_table', 1),
(47, '2021_08_19_063838_add_image_memos', 1),
(48, '2021_08_24_104925_add_image_memo_threads', 1),
(49, '2021_09_30_162110_create_acl_files_table', 1),
(50, '2021_10_08_154645_create_shared_file_table', 1),
(51, '2021_10_12_182905_create_department_table', 1),
(52, '2021_10_13_125108_create_vst_module_table', 1),
(53, '2021_10_13_125828_create_user_permission_table', 1),
(54, '2021_10_13_152826_add_department_id_users_table', 1),
(55, '2021_10_14_170028_add_company_id_department_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_by` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `project_type_id` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `project_status` int(11) NOT NULL DEFAULT '0',
  `start_date` varchar(191) DEFAULT NULL,
  `end_date` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `created_by`, `company_id`, `project_type_id`, `name`, `description`, `project_status`, `start_date`, `end_date`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 1, '1', 'Bussiness', NULL, 1, '11/10/2021 12:00 AM', '04/22/2022 12:00 AM', '2021-11-10 12:27:06', '2021-11-10 12:27:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `project_attachments`
--

DROP TABLE IF EXISTS `project_attachments`;
CREATE TABLE IF NOT EXISTS `project_attachments` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `attachment` json DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `project_types`
--

DROP TABLE IF EXISTS `project_types`;
CREATE TABLE IF NOT EXISTS `project_types` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `project_types`
--

INSERT INTO `project_types` (`id`, `company_id`, `created_by`, `name`, `description`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 2, 'Project type 1', NULL, 1, '2021-11-10 12:26:09', '2021-11-10 12:26:09', NULL),
(2, 1, 2, 'Project Type 2', NULL, 1, '2021-11-10 12:26:27', '2021-11-10 12:26:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `project_users`
--

DROP TABLE IF EXISTS `project_users`;
CREATE TABLE IF NOT EXISTS `project_users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `project_users`
--

INSERT INTO `project_users` (`id`, `user_id`, `project_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 3, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shared_file`
--

DROP TABLE IF EXISTS `shared_file`;
CREATE TABLE IF NOT EXISTS `shared_file` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `folder_id` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `shared_by` varchar(191) DEFAULT NULL,
  `shared_to` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `phone_number` varchar(191) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `company_id` bigint(20) UNSIGNED DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `company_role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `role` varchar(191) DEFAULT NULL COMMENT '1=''superadmin'',2=''company'',3=''user''',
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_company_id_foreign` (`company_id`),
  KEY `users_company_role_id_foreign` (`company_role_id`)
) ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `phone_number`, `status`, `company_id`, `department_id`, `company_role_id`, `role`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Anviam', '', '1234567890', 1, NULL, NULL, NULL, '1', 'superadmin@anviam.com', '2021-11-10 11:54:31', '$2y$10$jf5/zCMBTiBC5Ot9U85lHu2QyX/Aq3650XnV2YOVsxZhRVFX8q6MO', NULL, '2021-11-10 11:54:31', '2021-11-10 11:54:31', NULL),
(2, 'Pathor', 'PHP', '9878967857', 1, 1, NULL, NULL, '2', 'nrani@anviam.com', NULL, '$2y$10$PVBHWO0zvRkrtWqYTeYZVeCKSPCUnyyU4yAzLOsPFBaGuJ87nzGUq', NULL, '2021-11-10 11:57:02', '2021-11-10 11:57:06', NULL),
(3, 'neha', 'arora', '8786564567', 1, 1, 1, 1, '3', 'nrani+@anviam.com', NULL, '$2y$10$GwnxsJ/pA9a9.UIqUTiPlecqaoU6PvRHtN8cA6K.ZwiLzujgo06Hi', NULL, '2021-11-10 12:11:53', '2021-11-10 12:11:53', NULL),
(4, 'Neha', 'Aro', '3456756478', 1, 1, 1, 1, '3', 'nrani+2@anviam.com', NULL, '$2y$10$h3uy1ccGZT15JV0ru4Ufl.MQGWfiNO/wRRjQWwTnf2mY6JpixGxn6', NULL, '2021-11-10 12:25:35', '2021-11-10 12:25:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_company`
--

DROP TABLE IF EXISTS `user_company`;
CREATE TABLE IF NOT EXISTS `user_company` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `company_name` varchar(191) NOT NULL,
  `company_number` varchar(191) NOT NULL,
  `street` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL,
  `zip` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `user_company`
--

INSERT INTO `user_company` (`id`, `user_id`, `company_name`, `company_number`, `street`, `city`, `state`, `zip`, `country`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 2, 'Agilent Technologies Italia S.p.A.', '9875643567', 'A-45', 'mohali', 'punjab', '160055', 'insia', NULL, '2021-11-10 11:57:06', '2021-11-10 11:57:06');

-- --------------------------------------------------------

--
-- Table structure for table `user_messages`
--

DROP TABLE IF EXISTS `user_messages`;
CREATE TABLE IF NOT EXISTS `user_messages` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `message_id` int(10) UNSIGNED NOT NULL,
  `sender_id` int(10) UNSIGNED NOT NULL,
  `receiver_id` int(10) UNSIGNED DEFAULT NULL,
  `group_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1:group message, 0:personal message',
  `seen_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1:seen',
  `deliver_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1:delivered',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `user_messages`
--

INSERT INTO `user_messages` (`id`, `message_id`, `sender_id`, `receiver_id`, `group_id`, `type`, `seen_status`, `deliver_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 2, 3, 0, 0, 0, 0, '2021-11-10 12:27:35', '2021-11-10 12:27:35', NULL),
(2, 2, 2, 4, 0, 0, 0, 0, '2021-11-10 12:27:48', '2021-11-10 12:27:48', NULL),
(3, 3, 3, 2, 0, 0, 0, 0, '2021-11-11 07:13:41', '2021-11-11 07:13:41', NULL),
(4, 4, 3, 2, 0, 0, 0, 0, '2021-11-11 07:14:16', '2021-11-11 07:14:16', NULL),
(5, 5, 4, 2, 0, 0, 0, 0, '2021-11-11 12:31:50', '2021-11-11 12:31:50', NULL),
(6, 6, 4, 3, 0, 0, 0, 0, '2021-11-11 12:32:12', '2021-11-11 12:32:12', NULL),
(7, 7, 4, 2, 0, 0, 0, 0, '2021-11-11 12:32:34', '2021-11-11 12:32:34', NULL),
(8, 8, 2, 3, 0, 0, 0, 0, '2021-11-11 12:33:29', '2021-11-11 12:33:29', NULL),
(9, 9, 2, 4, 0, 0, 0, 0, '2021-11-11 12:33:48', '2021-11-11 12:33:48', NULL),
(10, 10, 2, 4, 0, 0, 0, 0, '2021-11-11 12:36:58', '2021-11-11 12:36:58', NULL),
(11, 11, 4, 2, 0, 0, 0, 0, '2021-11-11 12:37:23', '2021-11-11 12:37:23', NULL),
(12, 12, 2, 3, 0, 0, 0, 0, '2021-11-12 09:30:41', '2021-11-12 09:30:41', NULL),
(13, 13, 2, 3, 0, 0, 0, 0, '2021-11-12 09:30:42', '2021-11-12 09:30:42', NULL),
(14, 14, 2, 3, 0, 0, 0, 0, '2021-11-12 09:32:15', '2021-11-12 09:32:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_permission`
--

DROP TABLE IF EXISTS `user_permission`;
CREATE TABLE IF NOT EXISTS `user_permission` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `user_permission`
--

INSERT INTO `user_permission` (`id`, `user_id`, `module_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(70, 4, 9, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(69, 4, 8, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(68, 4, 7, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(67, 4, 6, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(66, 4, 5, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(65, 4, 4, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(64, 4, 3, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(63, 4, 2, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(62, 4, 1, NULL, '2021-11-11 08:03:10', '2021-11-11 08:03:10'),
(61, 3, 9, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(60, 3, 8, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(59, 3, 7, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(58, 3, 6, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(57, 3, 5, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(56, 3, 4, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(55, 3, 3, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(54, 3, 2, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57'),
(53, 3, 1, NULL, '2021-11-11 08:02:57', '2021-11-11 08:02:57');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Superadmin', '2021-11-10 11:54:31', '2021-11-10 11:54:31', NULL),
(2, 'Company', '2021-11-10 11:54:31', '2021-11-10 11:54:31', NULL),
(3, 'Role', '2021-11-10 11:54:31', '2021-11-10 11:54:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vst_module`
--

DROP TABLE IF EXISTS `vst_module`;
CREATE TABLE IF NOT EXISTS `vst_module` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ;

--
-- Dumping data for table `vst_module`
--

INSERT INTO `vst_module` (`id`, `name`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Roles', NULL, '2021-10-13 07:24:42', '2021-10-13 07:25:03'),
(2, 'Users', NULL, '2021-10-13 07:24:49', '2021-10-13 07:24:59'),
(3, 'Project Type', NULL, '2021-10-13 07:24:52', '2021-10-13 07:25:06'),
(4, 'Project', NULL, '2021-10-13 07:24:56', '2021-10-13 07:25:08'),
(5, 'Document Control', NULL, '2021-10-13 07:24:56', '2021-10-13 07:25:08'),
(6, 'Department', NULL, '2021-10-13 07:24:56', '2021-10-13 07:25:08'),
(7, 'Group Chat', NULL, '2021-10-13 07:24:56', '2021-10-13 07:25:08'),
(8, 'Users', NULL, '2021-10-13 07:24:56', '2021-10-13 07:25:08'),
(9, 'Issues', NULL, '2021-10-13 07:24:56', '2021-10-13 07:25:08');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
